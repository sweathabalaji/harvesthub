
import React, { useEffect, useState } from 'react';
import { 
  Carousel, 
  CarouselContent, 
  CarouselItem, 
  CarouselNext, 
  CarouselPrevious 
} from '@/components/ui/carousel';

// Define the slide interface
interface Slide {
  type: 'image' | 'video';
  src: string;
  alt?: string;
}

const AnimatedBanner = () => {
  const [autoPlay, setAutoPlay] = useState(true);
  const [currentSlide, setCurrentSlide] = useState(0);
  
  const slides: Slide[] = [
    {
      type: 'video',
      src: 'https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
      alt: 'Fresh produce from farm to table'
    },
    {
      type: 'image',
      src: 'https://images.unsplash.com/photo-1498579687545-d5a4fffb0a9e?q=80&w=2070',
      alt: 'Fresh vegetables'
    },
    {
      type: 'image',
      src: 'https://images.unsplash.com/photo-1610832958506-aa56368176cf?q=80&w=2070',
      alt: 'Organic fruits'
    }
  ];

  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (autoPlay) {
      interval = setInterval(() => {
        setCurrentSlide((prevSlide) => (prevSlide + 1) % slides.length);
      }, 5000); // Change slide every 5 seconds
    }
    
    return () => {
      if (interval) {
        clearInterval(interval);
      }
    };
  }, [autoPlay, slides.length]);

  return (
    <div className="w-full max-w-5xl mx-auto my-8 overflow-hidden rounded-lg shadow-xl">
      <Carousel 
        className="w-full" 
        onMouseEnter={() => setAutoPlay(false)}
        onMouseLeave={() => setAutoPlay(true)}
        setApi={(api) => {
          if (api) {
            api.on('select', () => {
              // Update current slide index when carousel changes
              setCurrentSlide(api.selectedScrollSnap());
            });
          }
        }}
      >
        <CarouselContent>
          {slides.map((slide, index) => (
            <CarouselItem key={index}>
              {slide.type === 'image' ? (
                <img 
                  src={slide.src} 
                  alt={slide.alt || 'Slide image'} 
                  className="w-full h-[400px] object-cover animate-fade-in"
                />
              ) : (
                <video 
                  src={slide.src} 
                  autoPlay 
                  muted 
                  loop
                  className="w-full h-[400px] object-cover"
                />
              )}
            </CarouselItem>
          ))}
        </CarouselContent>
        <div className="absolute z-10 bottom-4 left-0 right-0 flex justify-center gap-2">
          {slides.map((_, index) => (
            <button
              key={index}
              className={`w-3 h-3 rounded-full transition-all ${
                index === currentSlide ? 'bg-primary scale-125' : 'bg-primary/40'
              }`}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>
        <CarouselPrevious className="left-2 bg-white/80" />
        <CarouselNext className="right-2 bg-white/80" />
      </Carousel>
    </div>
  );
};

export default AnimatedBanner;
