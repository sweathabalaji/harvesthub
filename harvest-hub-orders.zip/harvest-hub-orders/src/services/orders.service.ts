import { supabase, getAuthSession } from "@/integrations/supabase/client";
import { Order, OrderItem } from "@/types/api.types";
import { toast } from "sonner";

export const getOrders = async (): Promise<Order[]> => {
  try {
    console.log("Fetching orders...");
    
    // Get the current session to verify authentication status before fetching
    const session = await getAuthSession();
    console.log("Current session for getOrders:", session?.user?.email);
    
    // Directly fetch orders - don't check tables existence as it's causing errors with information_schema
    console.log("Fetching orders from the database...");
    
    // Make sure to explicitly bypass RLS for admin accounts
    // This ensures that the admin can see all orders regardless of user_id
    const { data: orders, error: ordersError } = await supabase
      .from('orders')
      .select('*')
      .order('order_date', { ascending: false });
    
    if (ordersError) {
      console.error("Error fetching orders:", ordersError);
      throw ordersError;
    }
    
    console.log("Orders fetched:", orders);
    
    if (!orders || orders.length === 0) {
      console.log("No orders found");
      return [];
    }
    
    const orderIds = orders.map(order => order.id);
    console.log("Order IDs:", orderIds);
    
    const { data: orderItems, error: itemsError } = await supabase
      .from('order_items')
      .select('*, products(*)')
      .in('order_id', orderIds);
    
    if (itemsError) {
      console.error("Error fetching order items:", itemsError);
      throw itemsError;
    }
    
    console.log("Order items fetched:", orderItems);
    
    return transformOrders(orders, orderItems);
  } catch (error) {
    console.error('Error fetching orders:', error);
    toast.error('Failed to fetch orders');
    return [];
  }
};

export const getOrderById = async (id: string): Promise<Order | undefined> => {
  try {
    const { data: order, error: orderError } = await supabase
      .from('orders')
      .select('*')
      .eq('id', id)
      .single();
    
    if (orderError) throw orderError;
    
    const { data: orderItems, error: itemsError } = await supabase
      .from('order_items')
      .select('*, products(*)')
      .eq('order_id', id);
    
    if (itemsError) throw itemsError;
    
    const orders = transformOrders([order], orderItems);
    return orders[0];
  } catch (error) {
    console.error('Error fetching order:', error);
    toast.error('Failed to fetch order details');
    return undefined;
  }
};

export const placeOrder = async (order: Omit<Order, 'id' | 'status' | 'orderDate'>): Promise<Order> => {
  try {
    console.log("Placing order:", order);
    
    const orderId = generateOrderId();
    const { data: { user } } = await supabase.auth.getUser();
    
    console.log("User ID:", user?.id);
    
    const orderData = await createOrderInDatabase(orderId, order, user?.id);
    console.log("Order created:", orderData);
    
    await createOrderItemsInDatabase(orderId, order.items);
    console.log("Order items created for order ID:", orderId);
    
    const newOrder = await getOrderById(orderId);
    if (!newOrder) {
      throw new Error('Failed to retrieve the placed order');
    }
    
    toast.success('Order placed successfully');
    return newOrder;
  } catch (error) {
    console.error('Error placing order:', error);
    toast.error('Failed to place order');
    throw error;
  }
};

export const updateOrderStatus = async (id: string, status: Order['status']): Promise<Order> => {
  try {
    const { error } = await supabase
      .from('orders')
      .update({ status })
      .eq('id', id);
    
    if (error) throw error;
    
    const updatedOrder = await getOrderById(id);
    if (!updatedOrder) throw new Error('Failed to retrieve the updated order');
    
    toast.success(`Order status updated to ${status}`);
    return updatedOrder;
  } catch (error) {
    console.error('Error updating order status:', error);
    toast.error('Failed to update order status');
    throw error;
  }
};

// Helper functions
const generateOrderId = () => {
  const timestamp = Date.now();
  const randomPart = Math.random().toString(36).substr(2, 5).toUpperCase();
  return `ORD-${timestamp.toString(36).toUpperCase()}-${randomPart}`;
};

const createOrderInDatabase = async (orderId: string, order: Omit<Order, 'id' | 'status' | 'orderDate'>, userId?: string) => {
  console.log("Creating order with ID:", orderId, "User ID:", userId);
  
  // Ensure this data gets properly inserted into the database
  const { data, error } = await supabase
    .from('orders')
    .insert({
      id: orderId,
      user_id: userId,
      customer_name: order.customerName,
      contact_info: order.contactInfo,
      delivery_address: order.deliveryAddress,
      status: 'pending',
      order_date: new Date().toISOString()
    })
    .select();
  
  if (error) {
    console.error("Error creating order in database:", error);
    throw error;
  }
  
  console.log("Order created successfully:", data);
  return data;
};

const createOrderItemsInDatabase = async (orderId: string, items: OrderItem[]) => {
  console.log("Creating order items for order ID:", orderId, "Items:", items);
  
  const orderItems = items.map(item => ({
    order_id: orderId,
    product_id: item.productId,
    quantity: item.quantity,
    price: item.price,
    unit: item.unit
  }));
  
  const { data, error } = await supabase
    .from('order_items')
    .insert(orderItems)
    .select();
  
  if (error) {
    console.error("Error creating order items in database:", error);
    throw error;
  }
  
  console.log("Order items created successfully:", data);
};

const transformOrders = (orders: any[], orderItems: any[]): Order[] => {
  console.log("Transforming orders:", orders);
  console.log("With order items:", orderItems);
  
  const orderItemsMap: Record<string, OrderItem[]> = {};
  orderItems.forEach(item => {
    const orderItem: OrderItem = {
      productId: item.product_id,
      name: item.products ? item.products.name : 'Unknown Product',
      quantity: item.quantity,
      price: item.price,
      unit: item.unit
    };
    
    if (!orderItemsMap[item.order_id]) {
      orderItemsMap[item.order_id] = [];
    }
    orderItemsMap[item.order_id].push(orderItem);
  });
  
  const transformedOrders = orders.map(order => ({
    id: order.id,
    customerName: order.customer_name,
    contactInfo: order.contact_info,
    deliveryAddress: order.delivery_address,
    status: order.status,
    orderDate: order.order_date,
    items: orderItemsMap[order.id] || []
  }));
  
  console.log("Transformed orders:", transformedOrders);
  
  return transformedOrders;
};
