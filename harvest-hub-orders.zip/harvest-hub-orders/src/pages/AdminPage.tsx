import React, { useState, useEffect } from 'react';
import { getOrders, updateOrderStatus, getProducts, addProduct, updateProduct, deleteProduct, Order, Product, seedProducts } from '@/services/api';
import Navbar from '@/components/Navbar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import OrderStatusBadge from '@/components/OrderStatusBadge';
import { Package, ShoppingBasket, RefreshCw, Check, Trash, Edit, Plus, Save } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

const AdminPage = () => {
  const { toast } = useToast();
  const { currentUser } = useAuth();
  const [activeTab, setActiveTab] = useState('orders');
  
  const [orders, setOrders] = useState<Order[]>([]);
  const [loadingOrders, setLoadingOrders] = useState(true);
  
  const [products, setProducts] = useState<Product[]>([]);
  const [loadingProducts, setLoadingProducts] = useState(true);
  
  const [newProduct, setNewProduct] = useState<Omit<Product, 'id'>>({
    name: '',
    price: 0,
    imageUrl: '',
    description: '',
    unit: 'kg'
  });
  
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  
  useEffect(() => {
    console.log("ActiveTab changed to:", activeTab);
    console.log("Current admin user:", currentUser?.email);
    
    if (activeTab === 'orders') {
      loadOrders();
    } else if (activeTab === 'products') {
      loadProducts();
    }
  }, [activeTab, currentUser]);
  
  useEffect(() => {
    seedProducts();
  }, []);
  
  const loadOrders = async () => {
    setLoadingOrders(true);
    console.log("Loading orders with user:", currentUser?.email);
    
    try {
      const data = await getOrders();
      console.log("Orders loaded in AdminPage:", data);
      setOrders(data);
    } catch (error) {
      console.error('Error loading orders:', error);
      toast({
        title: 'Error',
        description: 'Failed to load orders',
        variant: 'destructive',
      });
    } finally {
      setLoadingOrders(false);
    }
  };
  
  const loadProducts = async () => {
    setLoadingProducts(true);
    try {
      const data = await getProducts();
      setProducts(data);
    } catch (error) {
      console.error('Error loading products:', error);
      toast({
        title: 'Error',
        description: 'Failed to load products',
        variant: 'destructive',
      });
    } finally {
      setLoadingProducts(false);
    }
  };
  
  const handleUpdateOrderStatus = async (orderId: string, status: Order['status']) => {
    try {
      await updateOrderStatus(orderId, status);
      
      setOrders(prev => prev.map(order => 
        order.id === orderId ? { ...order, status } : order
      ));
      
      toast({
        title: 'Status Updated',
        description: `Order ${orderId} status updated to ${status}`,
      });
    } catch (error) {
      console.error('Error updating order status:', error);
      toast({
        title: 'Error',
        description: 'Failed to update order status',
        variant: 'destructive',
      });
    }
  };
  
  const handleNewProductChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setNewProduct(prev => ({
      ...prev,
      [name]: name === 'price' ? parseFloat(value) || 0 : value
    }));
  };
  
  const handleNewProductUnitChange = (value: string) => {
    setNewProduct(prev => ({ ...prev, unit: value }));
  };
  
  const handleEditingProductChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    if (!editingProduct) return;
    
    const { name, value } = e.target;
    setEditingProduct(prev => ({
      ...prev!,
      [name]: name === 'price' ? parseFloat(value) || 0 : value
    }));
  };
  
  const handleEditingProductUnitChange = (value: string) => {
    if (!editingProduct) return;
    setEditingProduct(prev => ({ ...prev!, unit: value }));
  };
  
  const handleAddProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newProduct.name || newProduct.price <= 0 || !newProduct.imageUrl) {
      toast({
        title: 'Validation Error',
        description: 'Please fill in all required fields',
        variant: 'destructive',
      });
      return;
    }
    
    try {
      const addedProduct = await addProduct(newProduct);
      setProducts(prev => [...prev, addedProduct]);
      
      setNewProduct({
        name: '',
        price: 0,
        imageUrl: '',
        description: '',
        unit: 'kg'
      });
      
      toast({
        title: 'Product Added',
        description: `${addedProduct.name} added to inventory`,
      });
    } catch (error) {
      console.error('Error adding product:', error);
      toast({
        title: 'Error',
        description: 'Failed to add product',
        variant: 'destructive',
      });
    }
  };
  
  const startEditingProduct = (product: Product) => {
    setEditingProduct({ ...product });
  };
  
  const cancelEditingProduct = () => {
    setEditingProduct(null);
  };
  
  const handleSaveProduct = async () => {
    if (!editingProduct) return;
    
    try {
      const updatedProduct = await updateProduct(editingProduct.id, editingProduct);
      
      setProducts(prev => 
        prev.map(product => product.id === updatedProduct.id ? updatedProduct : product)
      );
      
      setEditingProduct(null);
      
      toast({
        title: 'Product Updated',
        description: `${updatedProduct.name} has been updated`,
      });
    } catch (error) {
      console.error('Error updating product:', error);
      toast({
        title: 'Error',
        description: 'Failed to update product',
        variant: 'destructive',
      });
    }
  };
  
  const handleDeleteProduct = async (productId: number) => {
    if (!confirm('Are you sure you want to delete this product?')) return;
    
    try {
      await deleteProduct(productId);
      
      setProducts(prev => prev.filter(product => product.id !== productId));
      
      toast({
        title: 'Product Deleted',
        description: 'Product has been removed from inventory',
      });
    } catch (error) {
      console.error('Error deleting product:', error);
      toast({
        title: 'Error',
        description: 'Failed to delete product',
        variant: 'destructive',
      });
    }
  };
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">Admin Dashboard</h1>
        
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-8">
            <TabsTrigger value="orders" className="flex items-center gap-2">
              <Package className="h-4 w-4" />
              Order Management
            </TabsTrigger>
            <TabsTrigger value="products" className="flex items-center gap-2">
              <ShoppingBasket className="h-4 w-4" />
              Inventory Management
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="orders">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>Orders</CardTitle>
                  <Button variant="outline" size="sm" onClick={loadOrders}>
                    <RefreshCw className="h-4 w-4 mr-2" />
                    Refresh
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {loadingOrders ? (
                  <div className="flex justify-center py-12">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
                  </div>
                ) : orders.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Order ID</TableHead>
                        <TableHead>Customer</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Items</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {orders.map(order => (
                        <TableRow key={order.id}>
                          <TableCell className="font-medium">{order.id}</TableCell>
                          <TableCell>
                            <div>{order.customerName}</div>
                            <div className="text-sm text-muted-foreground">{order.contactInfo}</div>
                          </TableCell>
                          <TableCell>{formatDate(order.orderDate)}</TableCell>
                          <TableCell>
                            <div className="space-y-1">
                              {order.items.map((item, index) => (
                                <div key={index} className="text-sm">
                                  {item.quantity} {item.unit || 'kg'} × {item.name} (₹{item.price.toFixed(2)})
                                </div>
                              ))}
                            </div>
                          </TableCell>
                          <TableCell>
                            <OrderStatusBadge status={order.status} />
                          </TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              {order.status === 'pending' && (
                                <Button 
                                  size="sm" 
                                  variant="outline"
                                  onClick={() => handleUpdateOrderStatus(order.id, 'in-progress')}
                                >
                                  <RefreshCw className="h-4 w-4 mr-1" />
                                  Process
                                </Button>
                              )}
                              {order.status === 'in-progress' && (
                                <Button 
                                  size="sm" 
                                  variant="outline"
                                  onClick={() => handleUpdateOrderStatus(order.id, 'delivered')}
                                >
                                  <Check className="h-4 w-4 mr-1" />
                                  Mark Delivered
                                </Button>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-12">
                    <Package className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
                    <h3 className="text-lg font-medium mb-2">No Orders Yet</h3>
                    <p className="text-muted-foreground">
                      Orders placed by customers will appear here.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="products">
            <div className="grid md:grid-cols-2 gap-8">
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <CardTitle>Product Inventory</CardTitle>
                    <Button variant="outline" size="sm" onClick={loadProducts}>
                      <RefreshCw className="h-4 w-4 mr-2" />
                      Refresh
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {loadingProducts ? (
                    <div className="flex justify-center py-12">
                      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
                    </div>
                  ) : products.length > 0 ? (
                    <div className="space-y-4">
                      {products.map(product => (
                        <div key={product.id} className="flex items-start gap-4 border-b pb-4">
                          {editingProduct?.id === product.id ? (
                            <div className="w-full space-y-4">
                              <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2">
                                  <Label htmlFor="edit-name">Name</Label>
                                  <Input
                                    id="edit-name"
                                    name="name"
                                    value={editingProduct.name}
                                    onChange={handleEditingProductChange}
                                  />
                                </div>
                                
                                <div className="space-y-2">
                                  <Label htmlFor="edit-price">Price</Label>
                                  <div className="relative">
                                    <span className="absolute left-3 top-2.5 text-muted-foreground">₹</span>
                                    <Input
                                      id="edit-price"
                                      name="price"
                                      type="number"
                                      step="0.01"
                                      className="pl-8"
                                      value={editingProduct.price}
                                      onChange={handleEditingProductChange}
                                    />
                                  </div>
                                  
                                  <Select 
                                    value={editingProduct.unit || 'kg'} 
                                    onValueChange={handleEditingProductUnitChange}
                                  >
                                    <SelectTrigger className="w-24">
                                      <SelectValue placeholder="Unit" />
                                    </SelectTrigger>
                                    <SelectContent>
                                      <SelectItem value="kg">kg</SelectItem>
                                      <SelectItem value="box">box</SelectItem>
                                      <SelectItem value="unit">unit</SelectItem>
                                      <SelectItem value="pack">pack</SelectItem>
                                      <SelectItem value="head">head</SelectItem>
                                    </SelectContent>
                                  </Select>
                                </div>
                              </div>
                              
                              <div className="space-y-2">
                                <Label htmlFor="edit-imageUrl">Image URL</Label>
                                <Input
                                  id="edit-imageUrl"
                                  name="imageUrl"
                                  value={editingProduct.imageUrl}
                                  onChange={handleEditingProductChange}
                                />
                              </div>
                              
                              <div className="space-y-2">
                                <Label htmlFor="edit-description">Description</Label>
                                <Textarea
                                  id="edit-description"
                                  name="description"
                                  value={editingProduct.description || ''}
                                  onChange={handleEditingProductChange}
                                />
                              </div>
                              
                              <div className="flex justify-end gap-2">
                                <Button 
                                  type="button"
                                  variant="outline"
                                  onClick={cancelEditingProduct}
                                >
                                  Cancel
                                </Button>
                                <Button 
                                  type="button"
                                  onClick={handleSaveProduct}
                                >
                                  <Save className="h-4 w-4 mr-2" />
                                  Save Changes
                                </Button>
                              </div>
                            </div>
                          ) : (
                            <>
                              <img 
                                src={product.imageUrl} 
                                alt={product.name}
                                className="w-16 h-16 object-cover rounded"
                              />
                              <div className="flex-grow">
                                <div className="flex justify-between">
                                  <h3 className="font-medium">{product.name}</h3>
                                  <span className="font-bold">
                                    ₹{product.price.toFixed(2)}/{product.unit || 'kg'}
                                  </span>
                                </div>
                                {product.description && (
                                  <p className="text-sm text-muted-foreground mt-1">
                                    {product.description}
                                  </p>
                                )}
                              </div>
                              <div className="flex gap-2">
                                <Button 
                                  variant="ghost" 
                                  size="icon"
                                  onClick={() => startEditingProduct(product)}
                                >
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button 
                                  variant="ghost" 
                                  size="icon"
                                  onClick={() => handleDeleteProduct(product.id)}
                                >
                                  <Trash className="h-4 w-4" />
                                </Button>
                              </div>
                            </>
                          )}
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <ShoppingBasket className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
                      <h3 className="text-lg font-medium mb-2">No Products Yet</h3>
                      <p className="text-muted-foreground">
                        Add products to your inventory using the form on the right.
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Plus className="h-5 w-5" />
                    Add New Product
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleAddProduct} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Product Name*</Label>
                      <Input
                        id="name"
                        name="name"
                        value={newProduct.name}
                        onChange={handleNewProductChange}
                        placeholder="e.g., Organic Carrots"
                        required
                      />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="price">Price*</Label>
                        <div className="relative">
                          <span className="absolute left-3 top-2.5 text-muted-foreground">₹</span>
                          <Input
                            id="price"
                            name="price"
                            type="number"
                            step="0.01"
                            className="pl-8"
                            value={newProduct.price || ''}
                            onChange={handleNewProductChange}
                            placeholder="0.00"
                            required
                          />
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="unit">Unit</Label>
                        <Select value={newProduct.unit} onValueChange={handleNewProductUnitChange}>
                          <SelectTrigger id="unit">
                            <SelectValue placeholder="Select a unit" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="kg">Kilogram (kg)</SelectItem>
                            <SelectItem value="box">Box</SelectItem>
                            <SelectItem value="unit">Unit</SelectItem>
                            <SelectItem value="pack">Pack</SelectItem>
                            <SelectItem value="head">Head</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="imageUrl">Image URL*</Label>
                      <Input
                        id="imageUrl"
                        name="imageUrl"
                        value={newProduct.imageUrl}
                        onChange={handleNewProductChange}
                        placeholder="https://example.com/image.jpg"
                        required
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="description">Description</Label>
                      <Textarea
                        id="description"
                        name="description"
                        value={newProduct.description}
                        onChange={handleNewProductChange}
                        placeholder="A short description of the product..."
                      />
                    </div>
                    
                    <Button type="submit" className="w-full">
                      <Plus className="h-4 w-4 mr-2" />
                      Add Product
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default AdminPage;
