
import React from 'react';

type OrderStatus = 'pending' | 'in-progress' | 'delivered';

interface OrderStatusBadgeProps {
  status: OrderStatus;
}

const OrderStatusBadge: React.FC<OrderStatusBadgeProps> = ({ status }) => {
  const getStatusClasses = () => {
    switch (status) {
      case 'pending':
        return 'status-badge pending';
      case 'in-progress':
        return 'status-badge in-progress';
      case 'delivered':
        return 'status-badge delivered';
      default:
        return 'status-badge';
    }
  };
  
  const getStatusText = () => {
    switch (status) {
      case 'pending':
        return 'Pending';
      case 'in-progress':
        return 'In Progress';
      case 'delivered':
        return 'Delivered';
      default:
        return 'Unknown';
    }
  };
  
  return (
    <span className={getStatusClasses()}>
      {getStatusText()}
    </span>
  );
};

export default OrderStatusBadge;
